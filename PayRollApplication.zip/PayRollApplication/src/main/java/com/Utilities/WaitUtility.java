package com.Utilities;

public class WaitUtility {

}
